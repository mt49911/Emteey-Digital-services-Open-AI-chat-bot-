async function sendMessage(message) {
  console.log("Sending message to API:", message);

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        messages: [{ role: "user", content: message }]
      })
    });

    const data = await response.json();
    console.log("API raw response:", data);

    let botReply = "❌ Error: No response from AI.";
    if (data.choices && data.choices[0]) {
      botReply = data.choices[0].message.content;
    }

    // Save to history
    saveToHistory({ role: "user", content: message });
    saveToHistory({ role: "bot", content: botReply });

    return botReply;
  } catch (error) {
    console.error("Error sending message:", error);
    return "⚠️ Network error. Check logs.";
  }
}

// DOM handling
const chatBox = document.querySelector(".chat-box");
const inputField = document.querySelector("#user-input");
const sendBtn = document.querySelector("#send-btn");

function addMessage(content, role) {
  const msg = document.createElement("div");
  msg.className = "msg " + role;
  msg.innerText = content;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

sendBtn.addEventListener("click", async () => {
  const userMsg = inputField.value.trim();
  if (!userMsg) return;

  addMessage(userMsg, "user");
  inputField.value = "";

  const botReply = await sendMessage(userMsg);
  addMessage(botReply, "bot");
});

// Save messages to localStorage
function saveToHistory(entry) {
  const history = JSON.parse(localStorage.getItem("chatHistory")) || [];
  history.push(entry);
  localStorage.setItem("chatHistory", JSON.stringify(history));
}